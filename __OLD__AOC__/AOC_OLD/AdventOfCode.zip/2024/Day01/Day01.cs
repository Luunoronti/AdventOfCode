
namespace Year_2024;

class Day01
{
    public string Part1(PartInput Input)
    {
        long response = Input.LineWidth;
        return response.ToString();
    }
    public string Part2(PartInput Input)
    {
        long response = Input.LineWidth;
        return response.ToString();
    }
}
