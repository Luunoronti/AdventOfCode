﻿global using AdventOfCode.Extensions;
global using AdventOfCode.Runtime;
global using Location = System.Numerics.Vector2;
global using AdventOfCode.Internals;
global using System.CommandLine;
global using StringSpan = System.ReadOnlySpan<char>;