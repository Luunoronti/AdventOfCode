﻿DayGenerator.GenerateDaysIfRequired();
DayRunner.Run();
RunReport.PrintResults();

Console.WriteLine("Test completed");
