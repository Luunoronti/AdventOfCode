
namespace Year2016;

class Day08
{
    public string Part1(PartInput Input)
    {
        var map = new Map<bool>(50, 6);





        long response = Input.LineWidth;
        return response.ToString();
    }
    public string Part2(PartInput Input)
    {
        long response = Input.LineWidth;
        return response.ToString();
    }
}
